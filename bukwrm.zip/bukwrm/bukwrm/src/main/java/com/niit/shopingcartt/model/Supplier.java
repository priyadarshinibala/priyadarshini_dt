package com.niit.shopingcartt.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="SUPPLIER")
@Component
	
 
public class Supplier {
	private String name;       
	private String add;
	@Id
	@Column(name = "id")
	private String id;
	public String getname() {    
		return name;
	}      
	public void setname(String sname) {
		this.name = sname;
	}
	public String getadd() {
		return add;
	}
	public void setadd(String add) {
		this.add = add;
	}
	public String getid() {
		return id;
	}
	public void setid(String id) {
		this.id = id;
	}

	

}
